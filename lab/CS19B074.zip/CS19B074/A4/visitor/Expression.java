package visitor;

import java.util.ArrayList;

public class Expression {
    public String opcode;
    public String fullexpr;
    public ArrayList<String> addrs = new ArrayList<>();
}
