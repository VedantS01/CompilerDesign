# Take Home Assignment, Compilers Design, CS3300

## Vedant Ashish Saboo
## CS19B074

### About

This assignment is dedicated to conversion of legal infix arithmetic expression, into a post fix expression.

This takes into account the following arithmetic opetaions: (ALL ON INTEGER VALUES)

* Addition 
* Subtraction 
* Division 
* Multiplication

In accordance with the natural precedance order.

The program outputs the post fix expression for the given infix expression.

### Usage

* ~$ make clean
* ~$ make infixtopostfix
* ~$ ./infixtopostfix

**INPUT IS READ FROM STDIN AND OUTPUT IS GIVEN ON STDOUT**

