// package tests.tc;

class test100 {
    public static void main(String[] args) {
        System.out.println(new A().run(2,3));
    }
}

class A {
    int[] a;
    int i;
    public int run(int i1, int i2) {
        a = new int[i1];
        a[i] = i2;
        return (new int[i1])[i];
    }
}
