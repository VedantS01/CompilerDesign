//error
class Error2
{
    public static void main(String[] str)
    {
        System.out.println(new A().temp(true));
    }    
}


class A
{
    int y ; 
    public int computeA(int a, int b, D d)
    {
        return 5;
    }

    public int temp(boolean arg1)
    {
        int x ;
        int y ; 

        return 5 ; 
    }
}