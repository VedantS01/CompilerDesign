//no error
class NoError2{
    public static void main(String[] a){
	System.out.println(new BS().Start((20+0)));
    }
}
// This class contains an array of integers and
// methods to initialize, print and search the array
// using Binary Search
class End {
	int hi;
}

class B extends C{
	int hello;
}
class A extends D {
	int hello;
}
class C extends E {

}
class D extends F{
	int x;
}
class E extends F{
	int x;
}
class F extends G{
	int x;
}
class G extends End{
	int x;
}
class BS{
    int[] number ;
    int size ;

    public int Start(int sz){
		E e;
		A a;
		B b;
		F f;
		e = new E();
		a = new A();
		b = new B();
		//e = (true)?a:b;
		f = (true)?a:b;
		return sz;
    }

}