class test75{
    public static void main(String[] a){
	System.out.println(new Test().start());
    }
}

class Test2 extends Test{

    public int start2(){

	Test test1;
	int j;

	j = test1.start(); //legal in MiniJava

	return 0;
    }
}

class Test {

    Test test;

    public int start(){
	
	return 0;
    }

}
