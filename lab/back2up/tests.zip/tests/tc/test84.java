class test84{
    public static void main(String[] a){
	System.out.println(new Test().start());
    }
}

class Test {

    Test test;
    int i;

    public int start(){

	i = test.next(true);	// TE
	
	return 0;
    }

    public int next(boolean b1, boolean b2){

	return 0;
    }

}
