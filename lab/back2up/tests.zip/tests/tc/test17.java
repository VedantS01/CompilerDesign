class test17{
    public static void main(String[] a){
	System.out.println(new Test().next());
    }
}

class Test{
	
    public int start(){

	int op;

	return 0;
    }

    public int next(){
	int result;
		
	result = op;	// TE TE

	return 0;
    }
}
