// error
class Error{
    public static void main(String[] a){
	System.out.println(new BS().Start((20+0)));
    }
}
// This class contains an array of integers and
// methods to initialize, print and search the array
// using Binary Search
class B {
	private int Sup(boolean x) {
		return 5;
	}
}
class A extends B{

}
class BS extends A{
    int[] number ;
    int size ;

    public int Start(int sz){
		return this.Sup(true);
    }
}