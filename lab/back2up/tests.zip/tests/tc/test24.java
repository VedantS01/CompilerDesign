class test24{
    public static void main(String[] a){
	System.out.println(new Test().start());
    }
}

class Test{

    boolean result;
	
    public int start(){

	result = !1;	// TE

	return 0;
    }
}
