class test44{
    public static void main(String[] a){
	System.out.println(new Test().start());
    }
}

class Test{
	
    public int start(){

	Test op;

	op[10] = 5;	// TE

	return 0;
    }
}
