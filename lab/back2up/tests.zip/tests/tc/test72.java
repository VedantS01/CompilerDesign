class test72{
    public static void main(String[] a){
	System.out.println(new Test().start());
    }
}

class Test extends NotPresent {  //TE

    public int start(){
	
	return 0;
    }
}
