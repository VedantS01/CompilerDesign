class MultiClass {
    public static void main(String[] a){
        System.out.println(new A1().run());
    }
}

class A1 {
    int val;
    public int run(){
        val = 123;
        return new A2().run();
    }
}

class A2 {
    int val;
    public int run(){
        val = 123;
        return new A3().run();
    }
}

class A3 {
    int val;
    public int run(){
        val = 123;
        return new A4().run();
    }
}

class A4 {
    int val;
    public int run(){
        val = 123;
        return new A5().run();
    }
}

class A5 {
    int val;
    public int run(){
        val = 123;
        return new A6().run();
    }
}

class A6 {
    int val;
    public int run(){
        val = 123;
        return new A7().run();
    }
}

class A7 {
    int val;
    public int run(){
        val = 123;
        return new A8().run();
    }
}

class A8 {
    int val;
    public int run(){
        val = 123;
        return new A9().run();
    }
}

class A9 {
    int val;
    public int run(){
        val = 123;
        return new A10().run();
    }
}

class A10 {
    int val;
    public int run(){
        val = 123;
        return new A11().run();
    }
}

class A11 {
    int val;
    public int run(){
        val = 123;
        return new A12().run();
    }
}

class A12 {
    int val;
    public int run(){
        val = 123;
        return new A13().run();
    }
}

class A13 {
    int val;
    public int run(){
        val = 123;
        return new A14().run();
    }
}

class A14 {
    int val;
    public int run(){
        val = 123;
        return new A15().run();
    }
}

class A15 {
    int val;
    public int run(){
        val = 123;
        return new A16().run();
    }
}

class A16 {
    int val;
    public int run(){
        val = 123;
        return new A17().run();
    }
}

class A17 {
    int val;
    public int run(){
        val = 123;
        return new A18().run();
    }
}

class A18 {
    int val;
    public int run(){
        val = 123;
        return new A19().run();
    }
}

class A19 {
    int val;
    public int run(){
        val = 123;
        return new A20().run();
    }
}

class A20 {
    int val;
    public int run(){
        val = 123;
        return new A21().run();
    }
}

class A21 {
    int val;
    public int run(){
        val = 123;
        return new A22().run();
    }
}

class A22 {
    int val;
    public int run(){
        val = 123;
        return new A23().run();
    }
}

class A23 {
    int val;
    public int run(){
        val = 123;
        return new A24().run();
    }
}

class A24 {
    int val;
    public int run(){
        val = 123;
        return new A25().run();
    }
}

class A25 {
    int val;
    public int run(){
        val = 123;
        return new A26().run();
    }
}

class A26 {
    int val;
    public int run(){
        val = 123;
        return new A27().run();
    }
}

class A27 {
    int val;
    public int run(){
        val = 123;
        return new A28().run();
    }
}

class A28 {
    int val;
    public int run(){
        val = 123;
        return new A29().run();
    }
}

class A29 {
    int val;
    public int run(){
        val = 123;
        return new A30().run();
    }
}

class A30 {
    int val;
    public int run(){
        val = 123;
        return new A31().run();
    }
}

class A31 {
    int val;
    public int run(){
        val = 123;
        return new A32().run();
    }
}

class A32 {
    int val;
    public int run(){
        val = 123;
        return new A33().run();
    }
}

class A33 {
    int val;
    public int run(){
        val = 123;
        return new A34().run();
    }
}

class A34 {
    int val;
    public int run(){
        val = 123;
        return new A35().run();
    }
}

class A35 {
    int val;
    public int run(){
        val = 123;
        return new A36().run();
    }
}

class A36 {
    int val;
    public int run(){
        val = 123;
        return new A37().run();
    }
}

class A37 {
    int val;
    public int run(){
        val = 123;
        return new A38().run();
    }
}

class A38 {
    int val;
    public int run(){
        val = 123;
        return new A39().run();
    }
}

class A39 {
    int val;
    public int run(){
        val = 123;
        return new A40().run();
    }
}

class A40 {
    int val;
    public int run(){
        val = 123;
        return new A41().run();
    }
}

class A41 {
    int val;
    public int run(){
        val = 123;
        return new A42().run();
    }
}

class A42 {
    int val;
    public int run(){
        val = 123;
        return new A43().run();
    }
}

class A43 {
    int val;
    public int run(){
        val = 123;
        return new A44().run();
    }
}

class A44 {
    int val;
    public int run(){
        val = 123;
        return new A45().run();
    }
}

class A45 {
    int val;
    public int run(){
        val = 123;
        return new A46().run();
    }
}

class A46 {
    int val;
    public int run(){
        val = 123;
        return new A47().run();
    }
}

class A47 {
    int val;
    public int run(){
        val = 123;
        return new A48().run();
    }
}

class A48 {
    int val;
    public int run(){
        val = 123;
        return new A49().run();
    }
}

class A49 {
    int val;
    public int run(){
        val = 123;
        return new A50().run();
    }
}

class A50 {
    int val;
    public int run(){
        val = 123;
        return new A51().run();
    }
}

class A51 {
    int val;
    public int run(){
        val = 123;
        return new A52().run();
    }
}

class A52 {
    int val;
    public int run(){
        val = 123;
        return new A53().run();
    }
}

class A53 {
    int val;
    public int run(){
        val = 123;
        return new A54().run();
    }
}

class A54 {
    int val;
    public int run(){
        val = 123;
        return new A55().run();
    }
}

class A55 {
    int val;
    public int run(){
        val = 123;
        return new A56().run();
    }
}

class A56 {
    int val;
    public int run(){
        val = 123;
        return new A57().run();
    }
}

class A57 {
    int val;
    public int run(){
        val = 123;
        return new A58().run();
    }
}

class A58 {
    int val;
    public int run(){
        val = 123;
        return new A59().run();
    }
}

class A59 {
    int val;
    public int run(){
        val = 123;
        return new A60().run();
    }
}

class A60 {
    int val;
    public int run(){
        val = 123;
        return new A61().run();
    }
}

class A61 {
    int val;
    public int run(){
        val = 123;
        return new A62().run();
    }
}

class A62 {
    int val;
    public int run(){
        val = 123;
        return new A63().run();
    }
}

class A63 {
    int val;
    public int run(){
        val = 123;
        return new A64().run();
    }
}

class A64 {
    int val;
    public int run(){
        val = 123;
        return new A65().run();
    }
}

class A65 {
    int val;
    public int run(){
        val = 123;
        return new A66().run();
    }
}

class A66 {
    int val;
    public int run(){
        val = 123;
        return new A67().run();
    }
}

class A67 {
    int val;
    public int run(){
        val = 123;
        return new A68().run();
    }
}

class A68 {
    int val;
    public int run(){
        val = 123;
        return new A69().run();
    }
}

class A69 {
    int val;
    public int run(){
        val = 123;
        return new A70().run();
    }
}

class A70 {
    int val;
    public int run(){
        val = 123;
        return new A71().run();
    }
}

class A71 {
    int val;
    public int run(){
        val = 123;
        return new A72().run();
    }
}

class A72 {
    int val;
    public int run(){
        val = 123;
        return new A73().run();
    }
}

class A73 {
    int val;
    public int run(){
        val = 123;
        return new A74().run();
    }
}

class A74 {
    int val;
    public int run(){
        val = 123;
        return new A75().run();
    }
}

class A75 {
    int val;
    public int run(){
        val = 123;
        return new A76().run();
    }
}

class A76 {
    int val;
    public int run(){
        val = 123;
        return new A77().run();
    }
}

class A77 {
    int val;
    public int run(){
        val = 123;
        return new A78().run();
    }
}

class A78 {
    int val;
    public int run(){
        val = 123;
        return new A79().run();
    }
}

class A79 {
    int val;
    public int run(){
        val = 123;
        return new A80().run();
    }
}

class A80 {
    int val;
    public int run(){
        val = 123;
        return new A81().run();
    }
}

class A81 {
    int val;
    public int run(){
        val = 123;
        return new A82().run();
    }
}

class A82 {
    int val;
    public int run(){
        val = 123;
        return new A83().run();
    }
}

class A83 {
    int val;
    public int run(){
        val = 123;
        return new A84().run();
    }
}

class A84 {
    int val;
    public int run(){
        val = 123;
        return new A85().run();
    }
}

class A85 {
    int val;
    public int run(){
        val = 123;
        return new A86().run();
    }
}

class A86 {
    int val;
    public int run(){
        val = 123;
        return new A87().run();
    }
}

class A87 {
    int val;
    public int run(){
        val = 123;
        return new A88().run();
    }
}

class A88 {
    int val;
    public int run(){
        val = 123;
        return new A89().run();
    }
}

class A89 {
    int val;
    public int run(){
        val = 123;
        return new A90().run();
    }
}

class A90 {
    int val;
    public int run(){
        val = 123;
        return new A91().run();
    }
}

class A91 {
    int val;
    public int run(){
        val = 123;
        return new A92().run();
    }
}

class A92 {
    int val;
    public int run(){
        val = 123;
        return new A93().run();
    }
}

class A93 {
    int val;
    public int run(){
        val = 123;
        return new A94().run();
    }
}

class A94 {
    int val;
    public int run(){
        val = 123;
        return new A95().run();
    }
}

class A95 {
    int val;
    public int run(){
        val = 123;
        return new A96().run();
    }
}

class A96 {
    int val;
    public int run(){
        val = 123;
        return new A97().run();
    }
}

class A97 {
    int val;
    public int run(){
        val = 123;
        return new A98().run();
    }
}

class A98 {
    int val;
    public int run(){
        val = 123;
        return new A99().run();
    }
}

class A99 {
    int val;
    public int run(){
        val = 123;
        return new A100().run();
    }
}

class A100 {
    int val;
    public int run(){
        val = 123;
        return val;
    }
}

