//error
class Error1{
    public static void main(String[] a){
	System.out.println(new BS().Start((20+0)));
    }
}
// This class contains an array of integers and
// methods to initialize, print and search the array
// using Binary Search
class A extends B {
	int x;
}
class B extends C {
	int x;
}
class C extends D {
	int x;
}
class D extends E {
	int x;
}
class E extends F {
	int x;
}
class F extends G {
}
class G extends D {
}
class BS{
    int[] number ;
    int size ;

    public int Start(int sz){
		return sz;
    }
}