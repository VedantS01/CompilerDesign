class test70{
    public static void main(String[] a){
	System.out.println(new Test().start());
    }
}

class Test {

    Test test;
    int i;

    public int start(){
	
	test = test.next(true);

	return 0;
    }

    public int next(boolean i) {

	i = false;	// TE

	return 0;
    }
}
