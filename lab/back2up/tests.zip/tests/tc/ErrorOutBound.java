class ErrorOutBound{
    public static void main(String[] a){
    	int[] arr;
		int i;
		System.out.println(1);
		i = 1000;
		i = i - 99;
		arr = new int[1];
		arr[i]=1;
		arr[0] = 1;
    }
}