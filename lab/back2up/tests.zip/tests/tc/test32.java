class test32{
    public static void main(String[] a){
	System.out.println(new Test().start());
    }
}

class Test{

    public int start(){

	int[] op;
	int[] op2;

	op = new int[op2];	// TE

	return 0;
    }
}
