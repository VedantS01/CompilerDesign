class NoMain {
    public int run(){
	    return 9;
    }
} 
