class test33{
    public static void main(String[] a){
	System.out.println(new Test().start());
    }
}

class Test{

    Test test;

    public int start(){

	int[] op;
	int[] op2;

	op = new int[test.next()];	// TE

	return 0;
    }

    public Test next() {
	return test;
    }
}
