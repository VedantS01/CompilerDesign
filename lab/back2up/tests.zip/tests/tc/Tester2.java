
class Tester2
{
    public static void main(String[] arg)
    {
        System.out.println(1);
    }
}

class A extends D
{

}

class B extends A
{

}

class C extends A 
{

}


class D extends Tester2
{

}