class test55{
    public static void main(String[] a){
	System.out.println(new Test().start());
    }
}

class Test{

    int[] result;
    int[] op;
	
    public int start(){

	result = new int[10];

	result = op;	

	return 0;
    }
}
