class test91{
    public static void main(String[] a){
	System.out.println(new Test().start());
    }
}

class Test {

    Test test;
    int[] i;

    public int start(){

	i = new int[10];

	test = test.next(i);	// TE TE
	
	return 0;
    }
}
